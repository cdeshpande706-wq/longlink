#include "radio_sim.hpp"

namespace radio_sim {

bool sendWithAck(const uint8_t *data, size_t len) {
  (void)data;
  (void)len;
  return random(100) < 80;
}

}  // namespace radio_sim
