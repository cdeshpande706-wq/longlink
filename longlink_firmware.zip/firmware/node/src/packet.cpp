#include "packet.hpp"

namespace packet {

// CRC-8 so the receiver can detect corrupted packets
uint8_t crc8(const uint8_t *data, size_t len) {
  uint8_t c = 0;
  for (size_t i = 0; i < len; i++) {
    c ^= data[i];
    for (uint8_t b = 0; b < 8; b++) c = (c & 0x80) ? (c << 1) ^ 0x07 : (c << 1);
  }
  return c;
}

size_t build(const Reading &r, uint8_t *buf) {
  size_t n = 0;
  auto put8  = [&](uint8_t v)  { buf[n++] = v; };
  auto put16 = [&](uint16_t v) { buf[n++] = v >> 8; buf[n++] = v & 0xFF; };
  auto put32 = [&](uint32_t v) { put16(v >> 16); put16(v & 0xFFFF); };

  put8(r.nodeId);
  put16(r.seq);
  put16((uint16_t)(int16_t)(r.airTempC * 100));
  put32((uint32_t)r.pressurePa);
  put16(r.distanceMm);
  put16((uint16_t)(int16_t)(r.soilTempC * 100));
  put8(r.flags | (r.hasGps ? FLAG_GPS : 0));
  if (r.hasGps) {                          // position only after a fresh fix
    put32((uint32_t)r.lat);
    put32((uint32_t)r.lon);
  }
  put8(crc8(buf, n));
  return n;
}

}  // namespace packet
