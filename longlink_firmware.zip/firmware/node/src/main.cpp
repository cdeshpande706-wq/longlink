/*
  LongLink - sensor node firmware

  One cycle: wake -> read every sensor -> decide if a GPS fix is needed
  -> wait for this node's time slot -> build packet (CRC) -> send with
  acknowledge + retry -> sleep.

  Sensors live in src/sensors/ (one .hpp/.cpp pair each).
  The radio and GPS are simulated for now (radio_sim, gps_sim).
*/

#include <Arduino.h>
#include <Wire.h>

#include "config.hpp"
#include "packet.hpp"
#include "radio_sim.hpp"
#include "sensors/bmp180.hpp"
#include "sensors/ds18b20.hpp"
#include "sensors/tof.hpp"
#include "sensors/mpu6050.hpp"
#include "sensors/gps_sim.hpp"

// Which sensors answered at boot
static bool okBMP = false, okDS = false, okToF = false, okMPU = false;

static volatile bool motionFlag = false;
static uint16_t seqNo = 0;
static uint32_t cycleCount = 0;

static void IRAM_ATTR onMotion() { motionFlag = true; }

// Lists every device that answers on the I2C wires
static void scanI2C() {
  Serial.print("I2C devices found:");
  int found = 0;
  for (uint8_t addr = 1; addr < 127; addr++) {
    Wire.beginTransmission(addr);
    if (Wire.endTransmission() == 0) {
      Serial.printf(" 0x%02X", addr);
      found++;
    }
  }
  if (!found) Serial.print(" none");
  Serial.println();
}

void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.println();
  Serial.println("=== LongLink sensor node ===");

  Wire.begin(PIN_SDA, PIN_SCL);
  pinMode(PIN_MOTION, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(PIN_MOTION), onMotion, FALLING);
  analogReadResolution(12);
  randomSeed(micros());

  scanI2C();

  okBMP = bmp180::begin();
  okDS  = ds18b20::begin();
  okToF = tof::begin();
  okMPU = mpu6050::begin();

  Serial.println("Sensor check:");
  Serial.printf("  BMP180   : %s\n", okBMP ? "OK" : "not found");
  Serial.printf("  DS18B20  : %s\n", okDS  ? "OK" : "not found");
  Serial.printf("  VL53L0X  : %s\n", okToF ? "OK" : "not found");
  Serial.printf("  MPU-6050 : %s\n", okMPU ? "OK" : "not found");
  Serial.println("  GPS      : simulated (fixed coordinates)");
}

void loop() {
  cycleCount++;
  Serial.printf("\n--- Wake #%lu ---\n", (unsigned long)cycleCount);

  // 1. Read every sensor (stand-in values if one is missing and USE_STAND_INS is on)
  float airTemp = 0, pressure = 0, soilTemp = 0;
  uint16_t distMm = 0;

  bool bmpNow = okBMP && bmp180::read(airTemp, pressure);
  if (!bmpNow && USE_STAND_INS) {
    airTemp  = 25.0f + random(-20, 21) / 10.0f;
    pressure = 101300 + random(-200, 201);
  }

  bool dsNow = okDS && ds18b20::read(soilTemp);
  if (!dsNow && USE_STAND_INS) {
    soilTemp = map(analogRead(PIN_SOIL_KNOB), 0, 4095, 0, 500) / 10.0f;   // 0-50 C
  }

  bool tofNow = okToF && tof::read(distMm);
  if (!tofNow && USE_STAND_INS) {
    distMm = map(analogRead(PIN_DIST_KNOB), 0, 4095, 30, 2000);           // 30-2000 mm
  }

  // Motion: accelerometer spread, or the pushbutton / interrupt pin
  float spread = 0;
  bool mpuNow = okMPU && mpu6050::sampleMotion(spread);
  bool moved = (mpuNow && spread > MOTION_G) || motionFlag;
  motionFlag = false;

  // 2. Decide whether a GPS fix is needed (saves power)
  bool sendGps = false;
  if (!gps_sim::hasFix()) {
    Serial.println("GPS: first fix at power-up");
    sendGps = true;
  } else if (moved) {
    Serial.println("GPS: motion detected, new fix");
    sendGps = true;
  } else if (cycleCount % GPS_REFRESH_CYCLES == 0) {
    Serial.println("GPS: periodic refresh");
    sendGps = true;
  }
  if (sendGps) gps_sim::takeFix();

  // 3. Wait for this node's time slot (offset + random jitter)
  uint32_t slotDelay = NODE_ID * SLOT_MS + random(0, 300);
  Serial.printf("Waiting %lu ms for my time slot\n", (unsigned long)slotDelay);
  delay(slotDelay);

  // 4. Build the packet
  packet::Reading r;
  r.nodeId     = NODE_ID;
  r.seq        = seqNo;
  r.airTempC   = airTemp;
  r.pressurePa = pressure;
  r.distanceMm = distMm;
  r.soilTempC  = soilTemp;
  r.flags      = (moved  ? packet::FLAG_MOTION  : 0) |
                 (bmpNow ? packet::FLAG_BMP180  : 0) |
                 (dsNow  ? packet::FLAG_DS18B20 : 0) |
                 (tofNow ? packet::FLAG_TOF     : 0) |
                 (mpuNow ? packet::FLAG_MPU     : 0);
  r.hasGps     = sendGps;
  r.lat        = gps_sim::lat();
  r.lon        = gps_sim::lon();

  uint8_t pkt[packet::MAX_SIZE];
  size_t n = packet::build(r, pkt);

  Serial.printf("Node %d #%u | air %.1f C | %.0f Pa | dist %u mm | soil %.1f C | motion %s\n",
                NODE_ID, seqNo, airTemp, pressure, distMm, soilTemp, moved ? "YES" : "no");
  Serial.printf("Real sensors this cycle: BMP180 %s, DS18B20 %s, VL53L0X %s, MPU-6050 %s (spread %.2f g)\n",
                bmpNow ? "yes" : "no", dsNow ? "yes" : "no", tofNow ? "yes" : "no",
                mpuNow ? "yes" : "no", spread);
  Serial.printf("Packet (%u bytes): ", (unsigned)n);
  for (size_t i = 0; i < n; i++) Serial.printf("%02X ", pkt[i]);
  Serial.println();

  // 5. Send with acknowledge and retry
  bool acked = false;
  for (uint8_t attempt = 1; attempt <= MAX_TRIES && !acked; attempt++) {
    acked = radio_sim::sendWithAck(pkt, n);
    Serial.printf("  attempt %d: %s\n", attempt, acked ? "ACK received" : "no ACK");
    if (!acked && attempt < MAX_TRIES) delay(random(200, 800));   // random back-off
  }
  if (!acked) {
    // Real node: store this reading and send it with the next one.
    // (Not implemented yet.)
    Serial.println("  no ACK after retries - reading lost");
  }
  seqNo++;   // the gateway spots gaps in sequence numbers as missing packets

  // 6. Sleep (simulation just waits; the real node will use deep sleep)
  Serial.printf("Sleeping %lu s (real node: deep sleep for 1 hour)\n", (unsigned long)CYCLE_SECONDS);
  delay(CYCLE_SECONDS * 1000UL);
}
