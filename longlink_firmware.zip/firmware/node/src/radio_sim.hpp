#pragma once
#include <Arduino.h>

namespace radio_sim {

// Simulated radio: about 80% of packets get an acknowledgement.
// In the real build this is replaced by the LoRa (SX1276/78) driver.
bool sendWithAck(const uint8_t *data, size_t len);

}  // namespace radio_sim
