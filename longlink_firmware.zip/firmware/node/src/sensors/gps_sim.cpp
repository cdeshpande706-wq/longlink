#include "gps_sim.hpp"

namespace gps_sim {

static bool fixed = false;
static int32_t latitude  = 0;
static int32_t longitude = 0;

void takeFix() {
  latitude  = 20593700;    // 20.5937 (example coordinates)
  longitude = 78962900;    // 78.9629
  fixed = true;
}

bool hasFix()  { return fixed; }
int32_t lat()  { return latitude; }
int32_t lon()  { return longitude; }

}  // namespace gps_sim
