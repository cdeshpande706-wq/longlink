#pragma once
#include <Arduino.h>

// MPU-6050: accelerometer + gyro (I2C, address 0x68 with AD0 tied to GND)
// Used to detect that the node was moved or shaken. No library needed:
// the accelerometer registers are read directly over I2C.
namespace mpu6050 {

bool begin();                                    // true if the sensor answered
bool readAccel(float &ax, float &ay, float &az); // acceleration in g

// Samples the accelerometer for about 200 ms and returns how much the total
// acceleration varied (max - min, in g). A still node gives a value near 0.
bool sampleMotion(float &spreadG);

}  // namespace mpu6050
