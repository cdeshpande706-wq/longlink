#pragma once
#include <Arduino.h>

// Simulated GPS: returns fixed example coordinates.
// Replace with a NEO-6M / NEO-M8N driver (UART) in the real build.
namespace gps_sim {

void takeFix();          // "acquire" a position
bool hasFix();           // true once takeFix() has been called
int32_t lat();           // degrees x 1,000,000
int32_t lon();

}  // namespace gps_sim
