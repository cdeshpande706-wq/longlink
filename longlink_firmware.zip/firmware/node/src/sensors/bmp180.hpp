#pragma once
#include <Arduino.h>

// BMP180: air temperature and pressure (I2C, address 0x77)
// Stand-in for the BME280 in the simulation; also usable on real hardware.
namespace bmp180 {

bool begin();                                   // true if the sensor answered
bool read(float &tempC, float &pressurePa);     // false if the sensor is missing

}  // namespace bmp180
