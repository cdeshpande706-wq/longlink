#pragma once
#include <Arduino.h>

// DS18B20: waterproof soil / water temperature probe (1-Wire)
// Needs a 4.7 kOhm resistor between the data line and 3V3.
namespace ds18b20 {

bool begin();                 // true if a probe was found
bool read(float &tempC);      // false if missing or disconnected

}  // namespace ds18b20
