#include "bmp180.hpp"
#include <Adafruit_BMP085.h>   // this library also drives the BMP180

namespace bmp180 {

static Adafruit_BMP085 sensor;
static bool ready = false;

bool begin() {
  ready = sensor.begin();
  return ready;
}

bool read(float &tempC, float &pressurePa) {
  if (!ready) return false;
  tempC      = sensor.readTemperature();
  pressurePa = sensor.readPressure();
  return true;
}

}  // namespace bmp180
