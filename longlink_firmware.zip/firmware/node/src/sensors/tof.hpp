#pragma once
#include <Arduino.h>

// VL53L0X: time-of-flight distance sensor (I2C, address 0x29)
// Used for water level, object presence, door open/closed.
namespace tof {

bool begin();                       // true if the sensor answered
bool read(uint16_t &distanceMm);    // false if missing or timed out

}  // namespace tof
