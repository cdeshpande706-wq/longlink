#include "ds18b20.hpp"
#include "../config.hpp"
#include <OneWire.h>
#include <DallasTemperature.h>

namespace ds18b20 {

static OneWire oneWire(PIN_DS18B20);
static DallasTemperature probe(&oneWire);
static bool ready = false;

bool begin() {
  probe.begin();
  ready = probe.getDeviceCount() > 0;
  return ready;
}

bool read(float &tempC) {
  if (!ready) return false;
  probe.requestTemperatures();
  float t = probe.getTempCByIndex(0);
  if (t < -100) return false;      // the library returns -127 when disconnected
  tempC = t;
  return true;
}

}  // namespace ds18b20
