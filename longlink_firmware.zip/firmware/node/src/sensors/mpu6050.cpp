#include "mpu6050.hpp"
#include "../config.hpp"
#include <Wire.h>

namespace mpu6050 {

bool begin() {
  Wire.beginTransmission(MPU_ADDR);
  if (Wire.endTransmission() != 0) return false;
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x6B);                 // power management register
  Wire.write(0);                    // wake the sensor up
  return Wire.endTransmission() == 0;
}

bool readAccel(float &ax, float &ay, float &az) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x3B);                 // first accelerometer register
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((uint8_t)MPU_ADDR, (size_t)6) != 6) return false;
  int16_t x = (Wire.read() << 8) | Wire.read();
  int16_t y = (Wire.read() << 8) | Wire.read();
  int16_t z = (Wire.read() << 8) | Wire.read();
  ax = x / 16384.0f;                // default range +/-2 g
  ay = y / 16384.0f;
  az = z / 16384.0f;
  return true;
}

bool sampleMotion(float &spreadG) {
  float mn = 99.0f, mx = 0.0f;
  int good = 0;
  for (int i = 0; i < 20; i++) {
    float ax, ay, az;
    if (readAccel(ax, ay, az)) {
      float m = sqrtf(ax * ax + ay * ay + az * az);
      if (m < mn) mn = m;
      if (m > mx) mx = m;
      good++;
    }
    delay(10);
  }
  if (good == 0) return false;
  spreadG = mx - mn;
  return true;
}

}  // namespace mpu6050
