#include "tof.hpp"
#include <VL53L0X.h>

namespace tof {

static VL53L0X sensor;
static bool ready = false;

bool begin() {
  sensor.setTimeout(500);
  ready = sensor.init();
  return ready;
}

bool read(uint16_t &distanceMm) {
  if (!ready) return false;
  uint16_t d = sensor.readRangeSingleMillimeters();
  if (sensor.timeoutOccurred()) return false;
  distanceMm = d;
  return true;
}

}  // namespace tof
