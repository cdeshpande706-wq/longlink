#pragma once
#include <Arduino.h>

// ---------------- Board pins ----------------
#if defined(CONFIG_IDF_TARGET_ESP32S3)
  // ESP32-S3 (Cirkit Designer simulation)
  constexpr uint8_t PIN_SDA       = 8;
  constexpr uint8_t PIN_SCL       = 9;
  constexpr uint8_t PIN_DS18B20   = 4;
  constexpr uint8_t PIN_MOTION    = 5;    // pushbutton to GND (simulation stand-in for MPU-6050 INT)
  constexpr uint8_t PIN_DIST_KNOB = 1;    // potentiometer, stand-in for the VL53L0X
  constexpr uint8_t PIN_SOIL_KNOB = 2;    // potentiometer, stand-in for the DS18B20
#else
  // Classic ESP32 DevKit (real hardware)
  constexpr uint8_t PIN_SDA       = 21;
  constexpr uint8_t PIN_SCL       = 22;
  constexpr uint8_t PIN_DS18B20   = 4;
  constexpr uint8_t PIN_MOTION    = 27;   // MPU-6050 INT (can wake the ESP32 from deep sleep)
  constexpr uint8_t PIN_DIST_KNOB = 34;
  constexpr uint8_t PIN_SOIL_KNOB = 35;
#endif

// ---------------- Node settings ----------------
constexpr uint8_t  NODE_ID            = 1;
constexpr uint32_t CYCLE_SECONDS      = 10;    // demo: 10 s. Real node: 3600 (1 hour)
constexpr uint32_t SLOT_MS            = 500;   // this node's slot offset = NODE_ID * SLOT_MS
constexpr uint32_t GPS_REFRESH_CYCLES = 6;     // demo "daily" refresh. Real node: 24
constexpr uint8_t  MAX_TRIES          = 3;     // send attempts per packet
constexpr uint8_t  MPU_ADDR           = 0x68;  // MPU-6050 I2C address (AD0 tied to GND)
constexpr float    MOTION_G           = 0.15f; // accelerometer spread (g) that counts as motion

// true  = use made-up values / knobs when a sensor is missing (simulation)
// false = report nothing for a missing sensor (real hardware)
constexpr bool     USE_STAND_INS      = true;
