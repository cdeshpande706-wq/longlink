#pragma once
#include <Arduino.h>

namespace packet {

// Bits of the flags byte
constexpr uint8_t FLAG_MOTION  = 1 << 0;   // node was moved
constexpr uint8_t FLAG_GPS     = 1 << 1;   // packet carries a GPS position
constexpr uint8_t FLAG_BMP180  = 1 << 2;   // BMP180 gave a real reading
constexpr uint8_t FLAG_DS18B20 = 1 << 3;   // DS18B20 gave a real reading
constexpr uint8_t FLAG_TOF     = 1 << 4;   // VL53L0X gave a real reading
constexpr uint8_t FLAG_MPU     = 1 << 5;   // MPU-6050 gave a real reading

// Everything one packet carries
struct Reading {
  uint8_t  nodeId;
  uint16_t seq;          // sequence number: gaps show missing packets
  float    airTempC;
  float    pressurePa;
  uint16_t distanceMm;
  float    soilTempC;
  uint8_t  flags;        // FLAG_* bits (FLAG_GPS is added automatically)
  bool     hasGps;       // true right after a fresh GPS fix
  int32_t  lat;          // degrees x 1,000,000
  int32_t  lon;
};

constexpr size_t MAX_SIZE = 32;            // buffer size needed for build()

uint8_t crc8(const uint8_t *data, size_t len);

// Writes the packet into buf and returns its length in bytes
// (15 without GPS, 23 with GPS). The last byte is the CRC.
size_t build(const Reading &r, uint8_t *buf);

}  // namespace packet
